import words from 'an-array-of-english-words';

const findAnagrams = (word, allWords) => {
    const letters = word.split('');

    // Your code here
}

console.log(findAnagrams('cinema', words));

/*
    Expected output: ['iceman', 'anemic']
*/