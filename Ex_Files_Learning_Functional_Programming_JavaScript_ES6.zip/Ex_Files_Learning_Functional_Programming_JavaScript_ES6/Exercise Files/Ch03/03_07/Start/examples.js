const mixedUpNumbers = [10, 2, 4, 3, 7, 5, 8, 9, 1, 6];
