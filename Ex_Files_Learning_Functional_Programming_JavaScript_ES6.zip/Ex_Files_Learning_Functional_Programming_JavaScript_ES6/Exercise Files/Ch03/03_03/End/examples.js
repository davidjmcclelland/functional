const numbers = [1, 2, 3, 4, 5];

const double = x => x * 2;

const doubledNumbers = numbers.map(double);

console.log(doubledNumbers);