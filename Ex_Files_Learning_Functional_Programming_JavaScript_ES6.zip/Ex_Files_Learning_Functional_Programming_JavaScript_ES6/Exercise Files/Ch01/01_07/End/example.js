const x = 5;
x = 6;

const numbers = [1,2,3,4,5];
numbers[0] = 100;
numbers.reverse();

const person = {
    name: 'John Doe',
    age: 34,
};
person.name = 'Bob';